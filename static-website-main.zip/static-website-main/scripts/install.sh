#!/bin/bash
echo "Running install script..."
# e.g., apt install nginx -y or yum install httpd -y
